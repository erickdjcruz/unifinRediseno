<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equipos',
  'LBL_TEAMS' => 'Equipos',
  'LBL_TEAM_ID' => 'Id Equipo',
  'LBL_ASSIGNED_TO_ID' => 'Id del Usuario Asignado',
  'LBL_ASSIGNED_TO_NAME' => 'Usuario',
  'LBL_TAGS_LINK' => 'Etiquetas',
  'LBL_TAGS' => 'Etiquetas',
  'LBL_ID' => 'Id.',
  'LBL_DATE_ENTERED' => 'Fecha de Creación',
  'LBL_DATE_MODIFIED' => 'Última Modificación',
  'LBL_MODIFIED' => 'Modificado por',
  'LBL_MODIFIED_ID' => 'Modificado Por Id',
  'LBL_MODIFIED_NAME' => 'Modificado por nombre',
  'LBL_CREATED' => 'Creado Por',
  'LBL_CREATED_ID' => 'Creado Por Id',
  'LBL_DOC_OWNER' => 'Propietario del documento',
  'LBL_USER_FAVORITES' => 'Usuarios Favoritos',
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Nombre',
  'LBL_CREATED_USER' => 'Creado Por Usuario',
  'LBL_MODIFIED_USER' => 'Modificado Por Usuario',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Quitar',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificado por nombre',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Creado por nombre',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Backlog Compromiso Lista',
  'LBL_MODULE_NAME' => 'Backlog Compromiso',
  'LBL_MODULE_TITLE' => 'Backlog Compromiso',
  'LBL_MODULE_NAME_SINGULAR' => 'Backlog Compromiso',
  'LBL_HOMEPAGE_TITLE' => 'Mi Backlog Compromiso',
  'LNK_NEW_RECORD' => 'Crear Backlog Compromiso',
  'LNK_LIST' => 'Vista Backlog Compromiso',
  'LNK_IMPORT_BKL_BACKLOG_COMPROMISO' => 'Importar Backlog Compromiso',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Backlog Compromiso',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Flujo de actividad',
  'LBL_BKL_BACKLOG_COMPROMISO_SUBPANEL_TITLE' => 'Backlog Compromiso',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Backlog Compromiso',
  'LNK_IMPORT_VCARD' => 'Importar Backlog Compromiso vCard',
  'LBL_IMPORT' => 'Importar Backlog Compromiso',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Backlog Compromiso record by importing a vCard from your file system.',
  'LBL_BKL_BACKLOG_COMPROMISO_FOCUS_DRAWER_DASHBOARD' => 'Backlog Compromiso Panel de Enfoque',
  'LBL_BKL_BACKLOG_COMPROMISO_RECORD_DASHBOARD' => 'Backlog Compromiso Tablero de Registro',
  'LBL_FECHA_COMPROMISO' => 'Fecha Compromiso',
  'LBL_CURRENCY' => 'Moneda',
  'LBL_MONTO_ORIGINAL' => 'Monto Compromiso Original',
  'LBL_MONTO_MODIFICADO' => 'Monto Compromiso Modificado',
  'LBL_MONTO_REAL' => 'Monto Real',
  'LBL_DIFERENCIA' => 'Diferencia',
);